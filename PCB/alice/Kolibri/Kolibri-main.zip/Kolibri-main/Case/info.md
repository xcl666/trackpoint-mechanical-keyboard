Use these files to laser cut your case. All layers use 3mm thick acrylic.

Case in the pictures uses frosted acrylic on top and bottom layer, everything else is clear acrylic.
