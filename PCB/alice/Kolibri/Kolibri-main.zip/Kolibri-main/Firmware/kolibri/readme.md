Alice-style keyboard with arrow cluster and rotary encoder support.

-Uses Elite-C and THT diodes
-Pcb gasket mount
-Pcb foam using 4mm Eva
-FR4 plate
-Stacked acrylic case
-Rgb underglow

https://github.com/kreme123/Kolibri