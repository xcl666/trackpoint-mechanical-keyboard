# 3D Printed Case

## TODO

- stack &amp; extrude `.stl` files for 3D printing from layer files (plate + highprofile, backplate + spacers (angled?))
- (optional) add mounting posts to the case (&amp; holes in the plate) for tray mount
- split `.stl` files for smaller printers
